package com.imooc.demo1.service;

import com.imooc.demo1.entity.Area;

import java.util.List;

//创建一个接口
public interface AreaService {
  /**
   * 获取区域列表
   *
   * @return
   */
  List<Area> getAreaList();

  /**
   * 通过区域Id获取区域信息
   *
   * @param areaId
   * @return
   */
  Area getAreaById(int areaId);

  /**
   * 增加区域信息
   *
   * @param area
   * @return
   */
  boolean addArea(Area area);

  /**
   * 修改区域信息
   *
   * @param area
   * @return
   */
  boolean modifyArea(Area area);

  /**
   * 删除区域信息
   *
   * @param
   * @return
   */
  boolean deleteArea(int areaId);

}
