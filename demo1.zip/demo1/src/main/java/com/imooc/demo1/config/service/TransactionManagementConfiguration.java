package com.imooc.demo1.config.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.TransactionManagementConfigurer;

import javax.sql.DataSource;

//spring配置
@Configuration
//开启事务管理
@EnableTransactionManagement
public class TransactionManagementConfiguration implements TransactionManagementConfigurer {

  //得有数据传入才可以事务控制,传入数据datasource
  @Autowired   //注入进去用下面代表数据
  private DataSource dataSource;
  @Override
  public PlatformTransactionManager annotationDrivenTransactionManager() {
    //用数据管理事务来管理
    return new DataSourceTransactionManager(dataSource);
  }
}
