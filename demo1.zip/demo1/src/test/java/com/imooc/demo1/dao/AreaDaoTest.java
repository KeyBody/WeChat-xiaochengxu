package com.imooc.demo1.dao;

import com.imooc.demo1.entity.Area;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
public class AreaDaoTest {

  @Autowired
  private AreaDao areaDao;

  @Test
  @Ignore
  public void queryArea() {
    List<Area> areaList = areaDao.queryArea();
    //这2是检查值我们添加来一个来必须改成数据库里有三个才可以不然报错
    assertEquals(2,areaList.size());
  }

  @Test
  @Ignore
  public void queryAreaById() {
    Area area = areaDao.queryAreaById(1);
    assertEquals("东苑",area.getAreaName());
  }

  @Test
  @Ignore
  public void insertArea() {
    Area area = new Area();
    area.setAreaName("南苑");
    area.setPriority(1);
    /**
     *  assertEquals 这是应用非常广泛的一个断言，它的作用是比较实际的值和用户预期的值是否一样，
     *  例如设置了一个南苑看有没南苑对应的一个。下面是返回值看时候成功
     */
    int effectedNum = areaDao.insertArea(area);
    assertEquals(1,effectedNum);
  }

  @Test
  @Ignore
  public void updateArea() {
    Area area = new Area();
    area.setAreaName("西苑");
    area.setAreaId(3);
    area.setLastEditTime(new Date());
    int effectedNum = areaDao.updateArea(area);
    assertEquals(1,effectedNum);
  }

  @Test
  public void deleteArea() {
    int effectedNum = areaDao.deleteArea(3);
    assertEquals(1,effectedNum);
  }
}